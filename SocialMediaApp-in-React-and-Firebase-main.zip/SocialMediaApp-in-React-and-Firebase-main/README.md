# SocialMediaApp-using-React-and-Firebase
 Social media app where user can authenticate, post and chat in global chat room. Used react for front end and firebase for database and backend.

Deployed here: https://social-veteran.surge.sh/
